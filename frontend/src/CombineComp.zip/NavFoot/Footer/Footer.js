import React from "react";
import logo from "../../Assete/images/Logo/PentagonePng.png"
import { Link } from "react-router-dom";
const Footer = () => {
  return (
    <>
      <footer className="text-center text-lg-start text-muted" style={{ backgroundColor: "black", color: "white" }}>

        <section className="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">

          <div className="me-5 d-none d-lg-block">
            <span>Get connected with us on social networks:</span>
          </div>

          <div className="social-links">

            <a style={{ color: "white" }} href="#" className="social-icon-link bi-whatsapp fs-3"></a>

            <a style={{ color: "white" }} href="#" className="social-icon-link bi-instagram fs-3"></a>

            <a style={{ color: "white" }} href="#" className="social-icon-link bi-linkedin fs-3"></a>

            <a style={{ color: "white" }} href="#" className="social-icon-link bi-facebook fs-3"></a>
          </div>

        </section>

        <section className="">
          <div className="container text-center text-md-start mt-5">

            <div className="row mt-3">
              <div className="col-md-6 col-lg-4 col-xl-3 mb-4">
                <h6 className="  fw-bold mb-4" style={{ color: "white" }}>
                  <i className="fas fa-gem me-3"></i> <img src={logo} style={{ height: "50px", width: "200px" }} />
                </h6>
                <p>
                  Here you can use rows and columns to organize your footer content. Lorem ipsum
                  dolor sit amet, consectetur adipisicing elit.
                </p>
              </div>

              <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                <h6 className="  fw-bold mb-4" style={{ color: "white" }}>
                  Products
                </h6>
                <p>
                  <a href="#!" className="text-reset">Catagories</a>
                </p>
                <p>
                  <a href="#!" className="text-reset">Industries</a>
                </p>
                <p>
                  <a href="#!" className="text-reset">Styles</a>
                </p>
                <p>
                  <a href="#!" className="text-reset">Product Type</a>
                </p>
              </div>

              <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                <h6 className="  fw-bold mb-4" style={{ color: "white" }}>
                  Useful links
                </h6>
                <p>
                  <a href="#!" className="text-reset">Home</a>
                </p>
                <p>
                  <a href="#!" className="text-reset">About</a>
                </p>
                <p>
                  <a href="#!" className="text-reset">Services</a>
                </p>
                <p>
                  <a href="#!" className="text-reset">Contact</a>
                </p>
              </div>

              <div className="col-md-6 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                <h6 className="  fw-bold mb-4" style={{ color: "white" }}>Contact</h6>
                <p><i className="social-icon-link bi-house fs-3"></i> Pentagon Services</p>
                <p>
                  <i className="social-icon-link bi-envelope fs-3"></i>
                  contact@pentagon.com
                </p>
                {/* <p><i className="social-icon-link bi-telephone fs-3"></i> 032333333333333</p> */}
                <p><i className="social-icon-link bi-telephone fs-3"></i> +123456789</p>
              </div>
            </div>

          </div>
        </section>

        <div className="text-center p-4" style={{ backgroundColor: "rgba(0, 0, 0, 0.05)" }}>
          © 2023 Copyright:
          <Link className="text-reset fw-bold" to="/" style={{ color: "#31c9f7" }}>pentagonpackaging.com</Link>
        </div>

      </footer>
    </>
  );
}
export default Footer;