const Env = {
  server: "https://backend.pentagonpackaging.com",
  // server: "http://localhost:8000",


}
export default Env;      