import React, { useState, useEffect, useRef, useMemo } from "react";
import "./AddNavBar.css";
import { Link } from "react-router-dom";
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import { Container, TextField, Button, Modal, Box, Typography, IconButton, Grid, TextareaAutosize, Chip, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useDropzone } from 'react-dropzone';
import ClearIcon from '@mui/icons-material/Clear';
import JoditEditor from "jodit-react";
import axios from "axios";
import Env from "../../../Environments/Env";
import { Card, CardContent, CardMedia } from '@mui/material';
import DOMPurify from 'dompurify';
import { getAsset } from "../../../utils/helper";
import DeleteIcon from '@mui/icons-material/Delete';
import Navbar from "../../DDNav/NavBar/DDNavbar";
import img from "../../../Assete/images/Logo/PentagonePng.png"
import One from "./One";
import Two from "./Two";
import Three from "./Three";
import Four from "./Four";

const AddNavBars = () => {
    const editor = useRef(null)
    const [industriesModalOpen, setIndustriesModalOpen] = useState(false);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState('');

    const [image, setImages] = useState("");
    const [imagesFront, setImagesFront] = useState([]);
    const [responseImages, setResponseImages] = useState([]);
    const [currentFocuskeyword, setCurrentFocuskeyword] = useState('');
    const [currentTag, setCurrentTag] = useState('');

    const [category, setCategory] = useState('');
    const [industry, setIndustry] = useState('');
    const [shapeStyle, setShapeStyle] = useState('');
    const [material, setMaterial] = useState('');


    const [tags, setTags] = useState([]);
    const [focuskeyword, setFocuskeyword] = useState([]);
    const [metaTitle, setMetaTitle] = useState("");
    const [productCatagory, setProductCatagory] = useState('');
    const [metaDescription, setMetaDescription] = useState('');

    const [getResp, setGetResp] = useState([]);
    const [useEffectResp, setUseEffectResp] = useState(true);


    const [deleteBlogId, setDeleteBlogId] = useState("");
    const [deleteModalOpen, setDeleteModalOpen] = useState(false);


    useEffect(() => {
        getBlogs();
    }, [responseImages])
    useEffect(() => {
        getBlogs();
    }, []);
    useEffect(() => {
        getBlogs();
    }, [useEffectResp]);


    const addBlogModal = () => {
        setIndustriesModalOpen(true);
    }
    const getBlogs = () => {
        axios.get(`${Env.server}/api/product/getAllProduct`)
            .then((resp) => {
                let res = resp.data.products;
                // console.log("sss========", res);
                // console.log("sss========", res.image);
                setGetResp(res);
            })
            .catch((err) => {
                console.log("err", err);
            })
    }
    const publishBlogNow = (imgFileName) => {
        let data = {
            title: title,
            description: description,
            industry: industry,
            shapeStyle: shapeStyle,
            material: material,
            image: imgFileName,
            mataTags: tags,
            mataDescription: metaDescription,
            mataTitle: metaTitle,
            FocusKeyWords: focuskeyword,
            productCatagory: productCatagory
        }
        if (!data) {
            alert("fill all fields");
        }
        axios.post(`${Env.server}/api/product/postNew`, data)
            .then((res) => {
                let resp = res.data.message;
                if (resp === "successSave") {
                    closeAddProductModal();
                } else {
                    alert("error not in catch");
                }
            })
            .catch((err) => {
                console.log("err------ooo", err);
                alert("catch error");
            })

    }
    const publishImage = () => {
        const formData = new FormData();
        formData.append('imagefront', imagesFront);
        console.log("muzz1-====", imagesFront)
        console.log("muzz2-====", image)
        image.forEach((img, index) => {
            formData.append(`images`, img);
        });
        let objectNames = [];
        axios.post(`${Env.server}/api/upload/multiple`, formData)
            .then((res) => {
                let resp = res.data.file;
                for (let i = 0; i < resp.length; i++) {
                    objectNames.push("/images/" + resp[i].filename);
                }
                setResponseImages(objectNames);
                if (res.data.message === "imagesSaved") {
                    publishBlogNow(objectNames);
                } else {
                    alert("error not in catch")
                }
            })
            .catch((err) => {
                console.log("err------ooo", err)
                alert("catch error");
            })
    }
    const handleInsideClick = (e) => {
        e.stopPropagation();
        const isClickable = e.target.tagName === 'DIV' || e.target.tagName === 'INPUT'; // Check if the clicked element is the drop zone or input
        if (isClickable) {
            if (e.target.tagName === 'DIV') {
                document.getElementById('fileInput').click(); // Trigger the file input click event
            }
        }
    };
    const closeAddProductModal = () => {
        setIndustriesModalOpen(false);
    }

    const onDrop = (acceptedFiles) => {
        setImages(acceptedFiles.map((file) => Object.assign(file, {
            preview: URL.createObjectURL(file)
        })));
        setImagesFront(acceptedFiles.map((file) => Object.assign(file, {
            preview: URL.createObjectURL(file)
        })));
    };
    const removeImage = (index) => {
        const updatedImagesfront = [...imagesFront];
        updatedImagesfront.splice(index, 1);
        setImagesFront(updatedImagesfront)

        const updatedImages = [...image];
        updatedImages.splice(index, 1);
        setImages(updatedImages);
    };
    const { getRootProps, getInputProps } = useDropzone({
        accept: 'image/*',
        onDrop,
    });


    const handleCategoryChange = (event) => {
        setCategory(event.target.value);
    };
    const handleIndustryChange = (event) => {
        setIndustry(event.target.value);
    };
    const handleShapeStyleChange = (event) => {
        setShapeStyle(event.target.value);
    };
    const handleMaterialChange = (event) => {
        setMaterial(event.target.value);
    };



    // Meta Tag   
    const handleTagChange = (event) => {
        setCurrentTag(event.target.value);
    };
    const handleKeyDown = (event) => {
        if (event.key === 'Enter' && currentTag.trim() !== '') {
            setTags([...tags, currentTag.trim()]);
            setCurrentTag('');
        }
    };
    const handleDelete = (tagToDelete) => {
        setTags((prevTags) => prevTags.filter((tag) => tag !== tagToDelete));
    };
    // Focus keywords
    const handleChangeFocusKeyword = (event) => {
        setCurrentFocuskeyword(event.target.value);
    };
    const handleKeyDownFocusKeyword = (event) => {
        if (event.key === 'Enter' && currentFocuskeyword.trim() !== '') {
            setFocuskeyword([...focuskeyword, currentFocuskeyword.trim()]);
            setCurrentFocuskeyword('');
        }
    };
    const handleDeleteFocusKeyword = (focuskeyToDelete) => {
        setFocuskeyword((prevFocuskey) => prevFocuskey.filter((focuskey) => focuskey !== focuskeyToDelete));
    };
    const handleDeleteBlog = (productId) => {
        setDeleteBlogId(productId);
        setDeleteModalOpen(true);
        // Implement your delete logic here, using the productId
        console.log(`Deleting product with ID: ${productId}`);
    };

    const handleDeleteModalClose = () => {
        setUseEffectResp(!useEffectResp);
        setDeleteModalOpen(false);
    }

    const ConfirmedDeleteBlog = () => {
        axios.delete(`${Env.server}/api/product/DeleteSinglProduct/${deleteBlogId}`)
            .then((res) => {
                if (res.data.message === "SuccessDelete") {
                    setUseEffectResp(!useEffectResp);
                    handleDeleteModalClose();
                }
            })
            .catch((err) => {
                console.log("err====>>>", err);
            })
    }

    return (
        <div className="bg-white body" >
            <div style={{ fontFamily: "'Poppins', sans-serif" }} >
                <Navbar />
            </div>
            <One />
            <br />
            <br />
            <br />
            <Two />
            <br />
            <br />
            <br />
            <Three />
            <br />
            <br />
            <br />
            <Four />
            <br />
            <br />
            <br />

        </div>
    );
}
export default AddNavBars;