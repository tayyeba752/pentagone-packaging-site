import {
    Container,
    TextField,
    Button,
    Modal,
    Box,
    Typography,
    IconButton,
    Grid,
    TextareaAutosize,
    Chip,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import "./css/Product.css";
import axios from "axios";
import Env from "../../Environments/Env";
import { Link, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { getAsset } from "../../utils/helper";


const Product = () => {
    const navigate = useNavigate();
    const [GetProduct, setGetProd] = useState([]);
    useEffect(() => {
        getBlogs();
    }, []);

    const singlcomponent = (id, title) => {
        navigate(`/GetaQuote/${id}/${title}`);
    }
    const getBlogs = () => {
        console.log("sss========");
        axios.get(`${Env.server}/api/industry/getAll`)
            .then((resp) => {
                let res = resp.data.industries;
                console.log("sss========", res);
                console.log("sss========", res.image);
                setGetProd(res);
            })
            .catch((err) => {
                console.log("err", err);
            })
    }

    return (
        <>
            <Grid container spacing={2}>
                <Grid
                    item
                    xs={12}
                    sm={12}
                    style={{ backgroundColor: "White", marginTop: "5%" }}
                >
                    <div className="d-flex justify-content-between">
                        <div className="ms-5 mt-3">
                            <span className="headiPro">Redefine experience of product packaging with ultimate styles of boxes   </span>
                        </div>
                        <div className="seemoreHead">
                            <Link to="/products" ><h5
                                style={{ color: "#1b80ad", marginRight: "30px" }}
                            >
                                Visit Products <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
                            </h5></Link>
                        </div>
                    </div>

                    {/* <p className="container ms-3" style={{ textAlign: "justify" }}>

                        Pentagone: Elevate your with, a sleek and innovative [type of product]. Designed for [target audience], it boasts [key features, e.g., durability, efficiency] and adds a touch of style to your [setting]. Experience excellence in [industry or lifestyle] with Pentagone's [Product Name].
                    </p> */}
                    <div className="row type-cat m-5" id="allproduct-section">
                        {GetProduct.slice(0, 8).map((product, index) => (
                            <div key={index} className="col-md-3 col-sm-6 mb-4">
                                <div className="section-type-box" style={{ height: "330px", width: "100%" }}>
                                    <a>
                                        <img
                                            src={getAsset(product?.image[0])}
                                            alt={product.title}
                                            style={{ height: "250px", width: "100%", }}
                                        />
                                        <div className="section-type-box-des">
                                            <center><button style={{ backgroundColor: "#1ea9d3", color: "white", borderRadius: "10px", fontWeight: "bolder" }} onClick={() => singlcomponent(product.industry, product.title)} >Get a Quote</button></center>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        ))}
                    </div>
                </Grid>
            </Grid >
        </>
    );
}
export default Product;