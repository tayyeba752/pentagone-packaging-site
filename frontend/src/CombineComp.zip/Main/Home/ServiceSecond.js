import Quote from "../../CombineComp/Quote";
import "./css/ServceSecond.css"

const ServiceSecond = () => {
    return (
        <div className="bodyBox">
            <div className="container mt-5 mb-5">
                <div className="row ">
                    <div className="col-lg-7">
                        <h2 className="" style={{ color: "#1b80ad" }}>Get your dream box printing ideas fulfilled in an efficient creative way</h2>
                        <p>There is a huge boom in cutting-edge, digital & offset printing services in emerging markets which urge you to adopt custom designs for your own printing boxes. A broad view of a specific part of the customized boxes, pop up logo or 3D effects and a long series of printing are offered by this platform. </p>
                        <ul className="ms-5 text-black fw-bold">
                            <li className="mb-1">
                                Ink-Raising
                            </li>
                            <li className="mb-1">emboss/Deboss</li>
                            <li className="mb-1">Foil Stamping</li>
                            <li className="mb-1">Spot UV</li>
                            <li className="mb-1">Letterpress</li>
                            <li className="mb-1">Lamination</li>
                        </ul>
                        <h3 className="fw-bold" style={{ color: "#1b80ad" }} >How can you innovate your ideas of packaging designs with Pentagon Packaging</h3>
                        <li className="fw-bold mt-0">Choose the custom box for shipping</li>

                        <p className="" style={{ marginBottom: "-2px" }}>Go through the available packaging models which are adaptive to the nature of your product. If you’re confused while deciding a particular design, shape & dimension, don’t be reluctant to reach us. </p>


                        <li className="fw-bold mt-0">A free instant quote facility</li>

                        <p className="" style={{ marginBottom: "-2px" }}>It’s very easy, simple, & fast to request a quote from us. Do mention the necessary packaging needs such as dimensions of box, existing supply chain, custom options, the number of boxes you require, designs you want, & internal deadlines.</p>
                        <li className="fw-bold mt-0">Accomplish your order now</li>

                        <p className="" style={{ marginBottom: "-2px" }}>After receiving your quote, our customer support team will instantly prepare your prepared quote & come back to you within 1-2 hours. Your packaging journey will face no hurdle in the process.</p>

                        <li className="fw-bold mt-0">Roll-on production</li>
                        <p className="" style={{ marginBottom: "-2px" }}>Now you can show your artwork on a custom die line file. We’ll review the 2D & 3D rendering of your stylish packaging. Your attention part is done here. Be relaxed and wait for your supreme branded packaging.</p>


                    </div>

                    <div className="col-lg-5">
                        <Quote />
                    </div>
                </div>


            </div>
        </div>
    );
}
export default ServiceSecond;