import React from 'react';
import "./css/HowToOrder.css";
import img1 from "../../Assete/images/product/Sweet.jpg";

const HowToOrder = () => {
    return (
        <div className="container mt-5">
            <h1 className="text-center" style={{ color: "#1b80ad" }}>
                How to Order?
            </h1>

            <div className="row justify-content-center">
                <div className='col-lg-5'>
                    <div className="d-flex">
                        <img src={img1} className="rounded m-1 img" alt="..." />
                        <img src={img1} className="rounded m-1 img" alt="..." />
                    </div>
                    <div className="d-flex">
                        <img src={img1} className="rounded m-1 img" alt="..." />
                        <img src={img1} className="rounded m-1 img" alt="..." />
                    </div>
                </div>
                <div className='col-lg-5 marginLeft'>
                    <p className='me-4 ms-4 mt-2' style={{ textAlign: "justify" }}>
                        {/* Your text here */}
                        Choose the right custom box packaging for your product.
                        Every brand seeks its product to be packed befittingly; the right choice of boxes is a vital case in packaging. Sometimes the selection of the packaging boxes becomes difficult for clients. Our packaging team of experts does not leave the clients alone and provides the necessary information about perfectly fitting custom boxes for products. <br />
                        Our customer service providers are active respondents to the queries related to;
                        <ul className='ms-5'>
                            <li>The right stock</li>
                            <li>Size of boxes</li>
                            <li>Color scheme</li>
                            <li>A suitable box quantity</li>
                            <li>Fast shipping of boxes</li>
                            <li>Fast shipping of boxes</li>
                        </ul>
                        <b>Have more queries?<br />
                            Contact our customer support center 24/7</b>
                    </p>

                </div>
            </div>
        </div>
    );
}

export default HowToOrder;
