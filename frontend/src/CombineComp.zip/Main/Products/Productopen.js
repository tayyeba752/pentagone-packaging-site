

import React, { useEffect, useState } from 'react';
import Quote from '../../CombineComp/Quote';
import Navbar from '../../NavFoot/NavBar/Navbar';
import Footer from '../../NavFoot/Footer/Footer';
import img1 from "../../Assete/2.png";
import { useParams } from 'react-router-dom';
import Env from "../../Environments/Env";
import axios from 'axios';
import { getAsset } from '../../utils/helper';

const Productopen = () => {
    const { title, id } = useParams();
    const [getDataPro, setGetDataPro] = useState([]);
    useEffect(() => {
        getProductById();
    }, [])
    useEffect(() => {
        console.log("abc===", id)
    }, [id]);

    useEffect(() => {
        console.log("abc===", id)
    }, [title]);

    const getProductById = () => {
        axios.get(`${Env.server}/api/product/getSingleProduct/${id}`)
            .then((res) => {
                console.log("abc-===33", res.data)
                console.log("abc-===22", res.data.message)
                console.log("abc-===11", res.data.products[0])
                if (res.data.message === "Success") {
                    setGetDataPro(res.data.products[0]);
                }
            })
            .catch((err) => {
                console.log("abc====>>>", err);
            })
    }


    return (




        <>

            <div className='bg-white'>
                <Navbar />
                <div className="bodyBox">
                    <div className="container mt-5 mb-5">
                        <div className="row ">
                            <div className="col-lg-8" style={{ textAlign: "justify" }}>
                                <div>
                                    <img src={getDataPro?.image && getDataPro.image[0] ? getAsset(getDataPro.image[0]) : ''} alt="pentagon_img" style={{ height: "450px", width: "730px", borderRadius: "10px" }} />

                                </div>
                                <br />
                                <div>
                                    <h2 className='fw-bold' style={{ color: "#2ab8e1" }}>{title}</h2>
                                    <p>
                                        {getDataPro?.description}

                                    </p>

                                </div>
                            </div>
                            <div className="col-lg-4 mb-5">
                                <Quote />
                            </div>
                        </div>


                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}
export default Productopen;