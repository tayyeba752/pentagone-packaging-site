import './App.css';
import ReactDOM from 'react-dom/client';
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './Main/Home/Home';
import Login from "./CombineComp/Login/Login";
import SignUp from './CombineComp/SignUp/SignUp';
import ContactUs from './Main/ContactUs/ContactUs';
import GetQuote from './Main/GetQuote/GetQuote';
import Products from './Main/Products/Product';
import Productopen from './Main/Products/Productopen';
import AdminDashboard from './Dashboard/DDLandingPage/AdminDashboard';
import AddProduct from './Dashboard/MainDashboard/Product/AddProduct';

export default function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          {/*   ===========   User Page   =========== */}
          <Route path="/" element={<Home />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/GetQuote" element={<GetQuote />} />
          <Route path="/products" element={<Products />} />

          {/*   ===========   Combine Page   =========== */}
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/Productopen/:title/:id" element={<Productopen />} />


          {/*   ===========   Admin Page   =========== */}
          <Route path="/Admin/Dashboard" element={<AdminDashboard />} />
          <Route path="/Admin/AddProduct" element={<AddProduct />} />

        </Routes>
      </BrowserRouter>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);

