import React, { useState, useEffect } from "react";
import Button from '@mui/material/Button';
import "./NavBar.css";
import { Link } from 'react-router-dom';
import { Grid, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';

import { ImLocation } from "react-icons/im";
import { AiOutlineMail } from "react-icons/ai";
import { BsPhone } from "react-icons/bs";

// industries image
import img1 from "../../Assete/images/navbar/pngwing.com.png";
import img2 from "../../Assete/images/navbar/retailBox.png";
import img3 from "../../Assete/images/navbar/shoes.png";
import img4 from "../../Assete/images/navbar/apparel.png";
import img5 from "../../Assete/images/navbar/food.png";
import img6 from "../../Assete/images/navbar/electric.png";
import img7 from "../../Assete/images/navbar/gift.png";
import logo2 from "../../Assete/images/Logo/PentagonePng.png"

// R1
import one1 from "../../Assete/images/navbar/R1/Corrugated.png"
import two1 from "../../Assete/images/navbar/R1/Cardboard.png"
import three1 from "../../Assete/images/navbar/R1/Kraft.png"
import four1 from "../../Assete/images/navbar/R1/Rigid.png"
import five1 from "../../Assete/images/navbar/R1/Bakery.png"
import six1 from "../../Assete/images/navbar/R1/Cosmetic.png"
import seven1 from "../../Assete/images/navbar/R1/Shipping.png"
import eight1 from "../../Assete/images/navbar/R1/Mailer.jpg"
import nine1 from "../../Assete/images/navbar/R1/Retail.png"

import one2 from "../../Assete/images/navbar/R2/Display.png"
import two2 from "../../Assete/images/navbar/R2/small.png"
import three2 from "../../Assete/images/navbar/R2/Gable.png"
import four2 from "../../Assete/images/navbar/R2/Pillow.png"
import five2 from "../../Assete/images/navbar/R2/cube.png"
import six2 from "../../Assete/images/navbar/R2/candle.png"
import seven2 from "../../Assete/images/navbar/R2/sweet.png"
import eight2 from "../../Assete/images/navbar/R2/cofee.png"
import nine2 from "../../Assete/images/navbar/R2/Electronic.png"


const Nav2 = () => {
    const navigate = useNavigate();

    let style1 = {
        fontWeight: "bolder",
        fontSize: "14px",
        color: "white"
    }


    return (
        <div className="sticky-top" style={{ marginTop: "-20px", backgroundColor: "#25abd0" }}>
            <nav class="navigation sw-megamenu" style={{ marginTop: "-20px", border: "none" }} role="navigation">
                <ul>
                    <li class="ui-menu-item level0 fl-left"><a target="_blank" class="level-top cursorPointer"><b style={style1}>Home</b></a></li>
                    <li class="ui-menu-item level0 fullwidth parent hoverFun"><a class="level-top cursorPointer" title="Industries" ><b style={style1}>Industries </b></a>
                        <div class="level0 submenu">
                            <div class="container">
                                <div class="menu-top-block">
                                    <div id="p-menu" class="drop-menu-section drop-menu-section--reset-browser-style drop-menu-section--reset-magento-style">
                                        <div class="drop-menu-section__inner">
                                            <div class="drop-menu-section-column ">
                                                <div class="drop-menu-section-column__title">
                                                    <div class="drop-menu-section-column__title"><span class="drop-menu-section-column__title__text mega-menu-title">Industries</span> </div>
                                                </div>
                                                <div class="drop-menu-section-column__content p-nav-industries">
                                                    <a class="drop-menu-section-item cursorPointer">
                                                        <div class="drop-menu-section-item__fig-wrap">
                                                            <img class="porto-lazyload" style={{ height: "50px", width: "50px" }} src={img1} alt="abc" />
                                                        </div>
                                                        <span>
                                                            Cosmetic  Boxes
                                                        </span>
                                                    </a>
                                                    <a class="drop-menu-section-item cursorPointer">
                                                        <div class="drop-menu-section-item__fig-wrap">
                                                            <img class="porto-lazyload" src={img2} style={{ height: "50px", width: "50px" }} alt="Automotive" />
                                                        </div>
                                                        <span>
                                                            Retail Boxes
                                                        </span>
                                                    </a>
                                                    <a class="drop-menu-section-item cursorPointer">
                                                        <div class="drop-menu-section-item__fig-wrap">
                                                            <img class="porto-lazyload" src={img3} style={{ height: "50px", width: "50px" }} alt="Automotive" />
                                                        </div>
                                                        <span>
                                                            Shoe Boxes
                                                        </span>
                                                    </a>

                                                </div>
                                            </div>
                                            <div class="drop-menu-section-column ">
                                                <div class="drop-menu-section-column__title"><span class="drop-menu-section-column__title__text"><br /></span>
                                                </div>
                                                <div class="drop-menu-section-column__content p-nav-industries">
                                                    <a class="drop-menu-section-item cursorPointer">
                                                        <div class="drop-menu-section-item__fig-wrap">
                                                            <img class="porto-lazyload" src={img4} style={{ height: "50px", width: "50px" }} alt="Cosmetics" />
                                                        </div>
                                                        <span>
                                                            Apparel Boxes
                                                        </span>
                                                    </a>
                                                    <a class="drop-menu-section-item cursorPointer">
                                                        <div class="drop-menu-section-item__fig-wrap">
                                                            <img class="porto-lazyload" src={img5} style={{ height: "50px", width: "50px" }} alt="Cosmetics" />
                                                        </div>
                                                        <span>
                                                            Food & Beverages
                                                        </span>
                                                    </a>

                                                </div>
                                            </div>
                                            <div class="drop-menu-section-column ">
                                                <div class="drop-menu-section-column__title"><span class="drop-menu-section-column__title__text"><br /></span>
                                                </div>
                                                <div class="drop-menu-section-column__content p-nav-industries">


                                                    <a class="drop-menu-section-item cursorPointer">
                                                        <div class="drop-menu-section-item__fig-wrap">
                                                            <img class="porto-lazyload" src={img6} style={{ height: "50px", width: "50px" }} alt="Restaurant" />
                                                        </div>
                                                        <span>
                                                            Electronic Boxes
                                                        </span>

                                                    </a>
                                                    <a class="drop-menu-section-item cursorPointer">
                                                        <div class="drop-menu-section-item__fig-wrap">
                                                            <img class="porto-lazyload" src={img7} style={{ height: "50px", width: "50px" }} alt="Restaurant" />
                                                        </div>
                                                        <span>
                                                            Gift Boxes
                                                        </span>
                                                    </a>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="menu-bottom-block">
                                    <a >Cosmetic  Boxes</a>
                                    <a >Retail Boxes</a>
                                    <a >Food &amp; Beverages</a>
                                    <a >Apparel Boxes</a>
                                    <a >Electronic Boxes</a>
                                    <a >Gift Boxes</a>
                                    <a >Shoe Boxes</a>

                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="ui-menu-item level0 fullwidth parent hoverFun">
                        <div class="open-children-toggle"></div><a class="level-top cursorPointer" title="Categories"><b style={style1}>Categories</b></a>
                        <div class="level0 submenu">
                            <div class="container">
                                <div class="menu-top-block">
                                    <div id="p-menu" class="drop-menu-section drop-menu-section--reset-browser-style drop-menu-section--reset-magento-style">
                                        <div class="drop-menu-section__inner">
                                            <div class="drop-menu-section-column">
                                                <div class="drop-menu-section-column__title">
                                                    <span class="drop-menu-section-column__title__text mega-menu-title">CATEGORIES</span>
                                                </div>
                                                <div class="drop-menu-section-column__content">
                                                    <a>
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={one1} alt="Corrugated" />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Corrugated Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>



                                                    <a>
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={two1} alt="Cardboard " />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Cardboard   Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>


                                                    <a  >
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={three1} alt="Kraft " />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Kraft   Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>


                                                    <a  >
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={four1} alt="Rigid " />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Rigid   Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>


                                                    <a  >
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={five1} alt="Bakery " />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Bakery   Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>


                                                    <a  >
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={six1} alt="Cosmetic " />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Cosmetic   Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>


                                                    <a  >
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={seven1} alt="Shipping " />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Shipping   Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>


                                                    <a  >
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={eight1} alt="Mailer" />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Mailer Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>


                                                    <a  >
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={nine1} alt="Retail" />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Retail Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>





                                                </div>
                                            </div>
                                            <div class="drop-menu-section-column">
                                                <div class="drop-menu-section-column__title"><span class="drop-menu-section-column__title__text mega-menu-title">CATEGORIES</span> </div>
                                                <div class="drop-menu-section-column__content">


                                                    <a  >
                                                        <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                            <div className="drop-menu-section-item__image">
                                                                {/* Use the imported image dynamically */}
                                                                <img className="porto-lazyload" src={one2} alt="Display  " />
                                                            </div>
                                                            <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                                <div className="drop-menu-section-item-content__description">
                                                                    <span>Display    Boxes</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>


                                                    <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                        <div className="drop-menu-section-item__image">
                                                            {/* Use the imported image dynamically */}
                                                            <img className="porto-lazyload" src={two2} alt="Small  " />
                                                        </div>
                                                        <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                            <div className="drop-menu-section-item-content__description">
                                                                <span>Small    Boxes</span>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                        <div className="drop-menu-section-item__image">
                                                            {/* Use the imported image dynamically */}
                                                            <img className="porto-lazyload" src={three2} alt="Gable  " />
                                                        </div>
                                                        <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                            <div className="drop-menu-section-item-content__description">
                                                                <span>Gable    Boxes</span>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                        <div className="drop-menu-section-item__image">
                                                            {/* Use the imported image dynamically */}
                                                            <img className="porto-lazyload" src={four2} alt="Pillow  " />
                                                        </div>
                                                        <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                            <div className="drop-menu-section-item-content__description">
                                                                <span>Pillow    Boxes</span>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                        <div className="drop-menu-section-item__image">
                                                            {/* Use the imported image dynamically */}
                                                            <img className="porto-lazyload" src={five2} alt="Cube  " />
                                                        </div>
                                                        <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                            <div className="drop-menu-section-item-content__description">
                                                                <span>Cube    Boxes</span>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                        <div className="drop-menu-section-item__image">
                                                            {/* Use the imported image dynamically */}
                                                            <img className="porto-lazyload" src={six2} alt="Candle  " />
                                                        </div>
                                                        <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                            <div className="drop-menu-section-item-content__description">
                                                                <span>Candle    Boxes</span>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                        <div className="drop-menu-section-item__image">
                                                            {/* Use the imported image dynamically */}
                                                            <img className="porto-lazyload" src={seven2} alt="Candy & Sweet  " />
                                                        </div>
                                                        <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                            <div className="drop-menu-section-item-content__description">
                                                                <span>Candy & Sweet    Boxes</span>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                        <div className="drop-menu-section-item__image">
                                                            {/* Use the imported image dynamically */}
                                                            <img className="porto-lazyload" src={eight2} alt="Coffee & tea  " />
                                                        </div>
                                                        <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                            <div className="drop-menu-section-item-content__description">
                                                                <span>Coffee & tea    Boxes</span>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div className="drop-menu-section-item drop-menu-section-item--hover-grey"  >
                                                        <div className="drop-menu-section-item__image">
                                                            {/* Use the imported image dynamically */}
                                                            <img className="porto-lazyload" src={nine2} alt="Electronic  " />
                                                        </div>
                                                        <div className="drop-menu-section-item-content drop-menu-section-item-content--margin-left">
                                                            <div className="drop-menu-section-item-content__description">
                                                                <span>Electronic    Boxes</span>
                                                            </div>
                                                        </div>
                                                    </div>




                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row"></div>
                                <div class="menu-bottom-block"><a >
                                    <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/foldingcarton.jpg" alt="Folding Carton" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                    <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/foldingcarton.jpg" alt="Folding Carton" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                    Folding Carton</a>
                                    <a  >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/corrugated.jpg" alt="Corrugated" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Corrugated</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/rigid.jpg" alt="Rigid" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Rigid</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/display.jpg" alt="Display" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Displays</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/bag-1.jpg" alt="Bags" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Paper Bags</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/bag-2.jpg" alt="Bags" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Reusable Bags</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/bag-3.jpg" alt="Bags" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Mailer Bags</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/bag-4.jpg" alt="Bags" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Pouches</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/sticker.jpg" alt="stickers" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Stickers & Labels </a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/insert.jpg" alt="Inserts" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Inserts</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/tin.jpg" alt="Inserts" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Tin</a>
                                    <a >
                                        <img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/eco-product.webp" alt="Inserts" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />
                                        Eco-friendly Packaging</a>
                                    <a ><img src="https://media.pakfactory.com/media_upload/coding_guide/mega-menu/option.jpg" alt="Option Library" style={{ marginRight: "12px", borderRadius: "4px", width: "32px" }} />Option Library</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="ui-menu-item level0 fullwidth parent hoverFun"><a class="level-top cursorPointer" title="Industries" ><b style={style1}>Shapes & Styles </b></a>
                        <div class="level0 submenu">
                            <div class="container">
                                <div class="menu-top-block">
                                    <div id="p-menu" class="drop-menu-section drop-menu-section--reset-browser-style drop-menu-section--reset-magento-style">
                                        <div class="drop-menu-section__inner">
                                            <div class="drop-menu-section-column ">
                                                <div class="drop-menu-section-column__content p-nav-industries">
                                                    <ul>
                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Sleeve   Boxes
                                                                </span>
                                                            </a>
                                                        </li>


                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Hang tab   Boxes
                                                                </span>
                                                            </a>
                                                        </li>


                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Pillow   Boxes
                                                                </span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="drop-menu-section-column ">

                                                <div class="drop-menu-section-column__content p-nav-industries">
                                                    <ul>
                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Gable   Boxes
                                                                </span>
                                                            </a>
                                                        </li>


                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Handle   Boxes
                                                                </span>
                                                            </a>
                                                        </li>


                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Display   Boxes
                                                                </span>
                                                            </a>
                                                        </li>
                                                    </ul>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="menu-bottom-block"><a >Cosmetic  Boxes</a>
                                    <a >Retail Boxes</a>
                                    <a >Food &amp; Beverages</a>
                                    <a >Apparel Boxes</a>
                                    <a >Electronic Boxes</a>
                                    <a >Gift Boxes</a>
                                    <a >Shoe Boxes</a>

                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="ui-menu-item level0 fullwidth parent hoverFun"><a class="level-top cursorPointer" title="Industries" ><b style={style1}>Material </b></a>
                        <div class="level0 submenu" >
                            <div class="container">
                                <div class="menu-top-block">
                                    <div id="p-menu" class="drop-menu-section drop-menu-section--reset-browser-style drop-menu-section--reset-magento-style">
                                        <div class="drop-menu-section__inner">
                                            <div class="drop-menu-section-column ">
                                                <div class="drop-menu-section-column__content p-nav-industries">
                                                    <ul>
                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> 	Corrugated Boxes
                                                                </span>
                                                            </a>
                                                        </li>


                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Cardboard   Boxes
                                                                </span>
                                                            </a>
                                                        </li>


                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Kraft Boxes
                                                                </span>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Paper Boxes
                                                                </span>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="drop-menu-section-item cursorPointer">
                                                                <span>
                                                                    <i class="fa fa-eercast" aria-hidden="true"></i> Rigid Boxes
                                                                </span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="menu-bottom-block"><a >Cosmetic  Boxes</a>
                                    <a >Retail Boxes</a>
                                    <a >Food &amp; Beverages</a>
                                    <a >Apparel Boxes</a>
                                    <a >Electronic Boxes</a>
                                    <a >Gift Boxes</a>
                                    <a >Shoe Boxes</a>

                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="ui-menu-item level0 fl-right hoverFun" onClick={() => navigate("/login")}><span class="level-top cursorPointer"><b style={style1}>Login</b></span></li>
                    <li class="ui-menu-item level0 fl-right hoverFun" onClick={() => navigate("/contact")}><a target="_blank" class="level-top cursorPointer"><b style={style1}>Contact Us </b></a></li>
                    <li class="ui-menu-item level0 fl-right hoverFun" onClick={() => navigate("/products")}><span class="level-top cursorPointer"><b style={style1}>Products</b></span></li>
                    {/* <li class="ui-menu-item level0 fl-right hoverFun"><a class="level-top cursorPointer"><b style={style1}>Blog</b></a></li> */}
                </ul>
            </nav>
        </div>
    );
};

export default Nav2;