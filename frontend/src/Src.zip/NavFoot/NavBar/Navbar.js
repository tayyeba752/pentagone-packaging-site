import React, { useState, useEffect, useRef } from "react";
import Button from '@mui/material/Button';
import "./NavBar.css";
import { Link } from 'react-router-dom';
import { Grid, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';

import { ImLocation } from "react-icons/im";
import { AiOutlineMail } from "react-icons/ai";
import { BsPhone } from "react-icons/bs";

// industries image
import img1 from "../../Assete/images/navbar/pngwing.com.png";
import img2 from "../../Assete/images/navbar/retailBox.png";
import img3 from "../../Assete/images/navbar/shoes.png";
import img4 from "../../Assete/images/navbar/apparel.png";
import img5 from "../../Assete/images/navbar/food.png";
import img6 from "../../Assete/images/navbar/electric.png";
import img7 from "../../Assete/images/navbar/gift.png";
import logo2 from "../../Assete/images/Logo/PentagonePng.png"

// R1 
import one1 from "../../Assete/images/navbar/R1/Corrugated.png"
import two1 from "../../Assete/images/navbar/R1/Cardboard.png"
import three1 from "../../Assete/images/navbar/R1/Kraft.png"
import four1 from "../../Assete/images/navbar/R1/Rigid.png"
import five1 from "../../Assete/images/navbar/R1/Bakery.png"
import six1 from "../../Assete/images/navbar/R1/Cosmetic.png"
import seven1 from "../../Assete/images/navbar/R1/Shipping.png"
import eight1 from "../../Assete/images/navbar/R1/Mailer.jpg"
import nine1 from "../../Assete/images/navbar/R1/Retail.png"

import one2 from "../../Assete/images/navbar/R2/Display.png"
import two2 from "../../Assete/images/navbar/R2/small.png"
import three2 from "../../Assete/images/navbar/R2/Gable.png"
import four2 from "../../Assete/images/navbar/R2/Pillow.png"
import five2 from "../../Assete/images/navbar/R2/cube.png"
import six2 from "../../Assete/images/navbar/R2/candle.png"
import seven2 from "../../Assete/images/navbar/R2/sweet.png"
import eight2 from "../../Assete/images/navbar/R2/cofee.png"
import nine2 from "../../Assete/images/navbar/R2/Electronic.png"
import FixButton1 from "../FixButton1";
import Nav2 from "./Nav2";


const Navbar = () => {
    const navigate = useNavigate();


    let style1 = {
        fontWeight: "bolder",
        fontSize: "14px"
    }

    return (
        <>
            <FixButton1 />
            <header class="page-header type16 header-newskin" >
                <div class="header content " style={{ marginTop: "-20px" }}>
                    <strong class="logo cursorPointer">
                        <Link to="/">
                            <img src={logo2} style={{ height: "60px" }} alt="Logo" />
                        </Link>
                    </strong>
                    <div class="miniquote-wrapper mt-5" >
                        <span>
                            <Button style={{ backgroundColor: "transparent", color: "#31c6f3", border: "none", fontWeight: "bolder", fontSize: "large" }} >
                                <span className="sizePh">  <i class="fa fa-phone" style={{ marginRight: "10px" }} aria-hidden="true"></i> +92323232323</span>
                            </Button>
                        </span>
                        <span >
                            <button type="button" className="btn btn-info rounded text-white bg-info fw-bold" >
                                <span className="sizeBuGetQuote" onClick={() => navigate('/GetQuote')}>Get A QUOTE</span>
                            </button>
                        </span>
                    </div>
                </div>
            </header>

            <Nav2 />



        </>
    );
};

export default Navbar;