const Env = {
  // server: "http://localhost:8000",
  server: "https://backend.pentagonpackaging.com",
}
export default Env;  