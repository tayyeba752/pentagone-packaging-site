import { Container, TextField, Button, Modal, Box, Typography, IconButton, Grid, TextareaAutosize, Chip, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import "./Css/Product.css"

const Products = () => {
    const productsData = [
        {
            id: 1,
            imageSrc: 'https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp',
            title: 'Pentagone Packaging',
            description: 'Pentagone Packaging Pentagone Packaging',
        },
        {
            id: 1,
            imageSrc: 'https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp',
            title: 'Pentagone Packaging',
            description: 'Pentagone Packaging Pentagone Packaging',
        },
        {
            id: 1,
            imageSrc: 'https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp',
            title: 'Pentagone Packaging',
            description: 'Pentagone Packaging Pentagone Packaging',
        },
        {
            id: 1,
            imageSrc: 'https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp',
            title: 'Pentagone Packaging',
            description: 'Pentagone Packaging Pentagone Packaging',
        },
        {
            id: 1,
            imageSrc: 'https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp',
            title: 'Pentagone Packaging',
            description: 'Pentagone Packaging Pentagone Packaging',
        },
        {
            id: 1,
            imageSrc: 'https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp',
            title: 'Pentagone Packaging',
            description: 'Pentagone Packaging Pentagone Packaging',
        },
        // Add more products as needed
    ];
    return (
        <>
            <Grid container spacing={2}>
                <Grid item xs={12} sm={12} style={{ backgroundColor: 'white', marginTop: '5%' }}>
                    <Grid container spacing={2}>
                        {/* Left side */}
                        <Grid item xs={12} sm={6}>
                            <Typography variant="h2" gutterBottom style={{ margin: '20px', color: '#2ab7e1' }}>
                                Products Left:
                            </Typography>
                        </Grid>

                        {/* Right side */}
                        <Grid item xs={12} sm={6} className="right-side">
                            <Typography variant="h3" gutterBottom style={{ margin: '20px', color: '#2ab7e1', textAlign: 'right' }}>
                                Products Right:
                            </Typography>
                        </Grid>
                    </Grid>

                    <div style={{ marginRight: "20px", marginLeft: "20px" }}>
                        <div className="row type-cat">
                            {productsData?.map((pro, index) => (
                                <div className="col-md-3 mb-4" key={index} style={{ paddingLeft: '8px', paddingRight: '8px' }}>
                                    {/* Adjusted padding for col-md-3 */}
                                    <div className="section-type-box">
                                        <a>
                                            <img
                                                src={pro.imageSrc}
                                                alt="folding carton boxes"
                                                className="img-fluid"
                                            />
                                            <div className="section-type-box-des">
                                                <h3>{pro.title}</h3>
                                                <p>{pro.description}</p>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            ))}
                            {/* Add more similar divs for additional boxes */}
                        </div>
                    </div>
                </Grid>
            </Grid>

        </>
    );
}
export default Products;