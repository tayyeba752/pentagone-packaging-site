import "./Css/Testimonials.css";
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import {Typography, Box} from '@mui/material';
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import Logo from "../Assete/images/people/senior-man-wearing-white-face-mask-covid-19-campaign-with-design-space.jpeg"

const testimonials = [
  { id: 1, name: "John", designation: "CEO", review: "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum", pic: "../Assete/images/people/senior-man-wearing-white-face-mask-covid-19-campaign-with-design-space.jpeg" },
  { id: 2, name: "Johns", designation: "CEO", review: "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum", pic: "../Assete/images/people/senior-man-wearing-white-face-mask-covid-19-campaign-with-design-space.jpeg" },
  { id: 3, name: "Johnss", designation: "CEO", review: "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum", pic: "../Assete/images/people/senior-man-wearing-white-face-mask-covid-19-campaign-with-design-space.jpeg" }  ,
  { id: 4, name: "Johnssss", designation: "CEO", review: "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum", pic: "../Assete/images/people/senior-man-wearing-white-face-mask-covid-19-campaign-with-design-space.jpeg" },
  { id: 5, name: "Johnsssss", designation: "CEO", review: "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum", pic: "../Assete/images/people/senior-man-wearing-white-face-mask-covid-19-campaign-with-design-space.jpeg" },
];

const Testimonials=()=>{ 
  const responsiveOptions = {
    0: {
      items: 1, // show one item on extra small screens (xs)
    },
    600: {
      items: 1, // show one item on small screens (sm)
    },
    900: {
      items: 2,
    },
    1000: {
      items: 3, // adjust the number of items for larger screens if needed
    },
  };
    return(
        <>
 
    <Box sx={{ margin: "2rem 0" }}>
      <Typography 
        variant="h3"
        align="center"
        sx={{
          color: "crimson",
          fontWeight: "bold",
        }}
      >
        Client's Reviews
      </Typography>
      <Typography
        variant="h4"
        align="center"
        sx={{
          color: "black",
          fontWeight: "bold",
          marginBottom: "2rem",
        }}
      >
        Testimonials
      </Typography>

      <Container maxWidth="xl">
        <OwlCarousel
          className="owl-theme"
          loop
          margin={10}
          nav
          responsive={responsiveOptions}
        >
         {testimonials.map((testimonial , index) => (
          <>
          <Box
          key={index}
            sx={{
              height: "200px",
              background: "#fff",
              padding: "20px",
              transition: ".5s",

              "&:hover": {
                background: "#d0d5db",
              },
            }}
          >
            <Box
              sx={{
                display: "flex",
              }}
            >
              <Box
                sx={{
                  width: 100,
                  height: 100,
                  "& > img": {
                    width: "100%",
                    height: "100%",
                    borderRadius: "50%",
                  },
                }}
              >
                <img src={testimonial.pic} alt="" />
              </Box>
              <Box>
                <Typography variant="h5">{testimonial.name}</Typography>
                <Typography variant="body1">{testimonial.desiignation}</Typography>
              </Box>
            </Box>
            <Typography>
              {" "}
              {testimonial.review}
            </Typography>
          </Box>
          
           
          </>
         ))}
        </OwlCarousel>
      </Container>
    </Box>

 

        </>
    );
}
export default Testimonials;