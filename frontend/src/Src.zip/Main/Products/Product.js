import {
  Container,
  TextField,
  Button,
  Modal,
  Box,
  Typography,
  IconButton,
  Grid,
  TextareaAutosize,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import Navbar from "../../NavFoot/NavBar/Navbar";
import Footer from "../../NavFoot/Footer/Footer";
import { useNavigate } from "react-router-dom";

const Products = () => {
  const navigate = useNavigate();
  const prod = [
    { id: 1, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 2, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 3, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
    { id: 4, src: "https://media.pakfactory.com/media_upload/coding_guide/folding-carton-boxes.webp", Title: "Pentagone Packaging ", para: "Pentagone Packaging Pentagone Packaging" },
  ];

  const singlcomponent = () => {
    navigate("/Productopen");
  }

  return (
    <>
      <div className="bg-white">
        <Navbar />
        <Grid container spacing={2} >
          <Grid
            item
            xs={12}
            sm={12}
          >
            <Typography
              variant="h2"
              gutterBottom
              className="fw-bold"
              style={{ margin: "20px", color: "#73ddfa" }}
            >
              Products:
            </Typography>
            <div className="row type-cat m-5" id="allproduct-section">
              {prod.map(product => (
                <div key={product.id} onClick={singlcomponent} className="col-md-3 col-sm-6 mb-4">
                  <div className="section-type-box" style={{ height: "420px", width: "100%", cursor: "pointer" }}>
                    <a>
                      <img
                        src={product.src}
                        alt={product.Title}
                        style={{ height: "250px", width: "100%" }}
                      />
                      <div className="section-type-box-des">
                        <h3>{product.Title}</h3>
                        <p>{product.para}</p>
                      </div>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </Grid>
        </Grid>
      </div>
      <Footer />
    </>
  );
}
export default Products;