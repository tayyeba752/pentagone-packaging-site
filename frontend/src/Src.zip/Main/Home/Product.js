import {
    Container,
    TextField,
    Button,
    Modal,
    Box,
    Typography,
    IconButton,
    Grid,
    TextareaAutosize,
    Chip,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import "./css/Product.css";
import axios from "axios";
import Env from "../../Environments/Env";
import { Link, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { getAsset } from "../../utils/helper";


const Product = () => {
    const navigate = useNavigate();
    const [GetProduct, setGetProd] = useState([]);
    useEffect(() => {
        getBlogs();
    }, []);

    const singlcomponent = (id, title) => {
        navigate(`./Productopen/${title}/${id}`);
    }
    const getBlogs = () => {
        console.log("sss========");
        axios.get(`${Env.server}/api/product/getAllProduct`)
            .then((resp) => {
                let res = resp.data.products;
                console.log("sss========", res);
                console.log("sss========", res.image);
                setGetProd(res);
            })
            .catch((err) => {
                console.log("err", err);
            })
    }

    return (
        <>
            <Grid container spacing={2}>
                <Grid
                    item
                    xs={12}
                    sm={12}
                    style={{ backgroundColor: "White", marginTop: "5%" }}
                >
                    <div className="d-flex justify-content-between">
                        <div className="ms-5">
                            <Typography
                                variant="h2"
                                gutterBottom
                                style={{ color: "#1b80ad" }}
                            >
                                Products:
                            </Typography>
                        </div>
                        <div className="seemoreHead">
                            <Link to="/products" ><h5
                                style={{ color: "#1b80ad", marginRight: "50px" }}
                            >
                                Visit More <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
                            </h5></Link>
                        </div>
                    </div>

                    <p className="container ms-3" style={{ textAlign: "justify" }}>

                        Pentagone: Elevate your with, a sleek and innovative [type of product]. Designed for [target audience], it boasts [key features, e.g., durability, efficiency] and adds a touch of style to your [setting]. Experience excellence in [industry or lifestyle] with Pentagone's [Product Name].
                    </p>
                    <div className="row type-cat m-5" id="allproduct-section">
                        {GetProduct.slice(0, 4).map(product => (
                            <div key={product._id} onClick={() => singlcomponent(product._id, product.title)} className="col-md-3 col-sm-6 mb-4">
                                <div className="section-type-box" style={{ height: "420px", width: "100%" }}>
                                    <a>
                                        <img
                                            src={getAsset(product?.image[0])}
                                            alt={product.Title}
                                            style={{ height: "250px", width: "100%" }}
                                        />
                                        <div className="section-type-box-des">
                                            <h3 style={{ color: "#25abd0" }}>{product.title}</h3>
                                            <p>{product.description}</p>
                                        </div>
                                        <div className="text-info" style={{ position: "absolute", bottom: 10, cursor: "pointer", right: 30 }}>
                                            See more <i className="fa fa-angle-double-right" aria-hidden="true"></i>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        ))}
                    </div>
                </Grid>
            </Grid >
        </>
    );
}
export default Product;