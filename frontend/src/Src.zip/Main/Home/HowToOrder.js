import React from 'react';
import "./css/HowToOrder.css";
import img1 from "../../Assete/images/product/Sweet.jpg";

const HowToOrder = () => {
    return (
        <div className="container mt-5">
            <h1 className="text-center" style={{ color: "#1b80ad" }}>
                How to Order?
            </h1>

            <div className="row justify-content-center">
                <div className='col-lg-5'>
                    <div className="d-flex">
                        <img src={img1} className="rounded m-1" alt="..." />
                        <img src={img1} className="rounded m-1" alt="..." />
                    </div>
                    <div className="d-flex">
                        <img src={img1} className="rounded m-1" alt="..." />
                        <img src={img1} className="rounded m-1" alt="..." />
                    </div>
                </div>
                <div className='col-lg-5 marginLeft'>
                    <p className='me-4 ms-4 ' style={{ textAlign: "justify" }}>
                        {/* Your text here */}
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero maiores unde quisquam numquam beatae voluptates velit cum placeat ad voluptate amet possimus enim veritatis tempora sit iusto nihil sint, odit sequi quam eum culpa pariatur suscipit. Maxime eligendi nobis hic!
                    </p>
                    <p className='me-4 ms-4' style={{ textAlign: "justify" }}>
                        {/* Your text here */}
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quam cumque quibusdam, hic placeat porro totam eaque quae amet repudiandae tempora magni quod ducimus officiis repellat laudantium voluptates similique. In totam perferendis expedita tempora voluptates officia vel odit fugiat, exercitationem cupiditate necessitatibus inventore. Ut, nobis. Consequatur voluptatibus delectus, reiciendis fugit eius dolorum. Corporis, accusamus deleniti. Itaque possimus, repudiandae facere saepe expedita accusantium cum ad eum recusandae pariatur quaerat, qui alias ut eaque voluptatibus officia aperiam perferendis laboriosam molestiae optio minus. Doloremque optio eos exercitationem recusandae vel consequatur corrupti? Error fuga architecto debitis at. Quidem in, ipsam ullam omnis laborum est?
                    </p>
                </div>
            </div>
        </div>
    );
}

export default HowToOrder;
