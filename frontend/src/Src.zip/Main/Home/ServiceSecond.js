import Quote from "../../CombineComp/Quote";
import "./css/ServceSecond.css"

const ServiceSecond = () => {
    return (
        <div className="bodyBox">
            <div className="container mt-5 mb-5">
                <div className="row "> 
                    <div className="col-lg-6" style={{ textAlign: "justify" }}>
                        <h2 className="" style={{ color: "#1b80ad" }}>Experts Sieve All Detail to Help You Order Right Custom Boxes</h2>
                        <p className="">Finding custom boxes online is easy, but ordering the right one without experience is incredibly hard. With Emenac Packaging, it never is.</p>
                        <p className="">Here, real packaging experts pore over the details in run-time to assist you choose the right stock, size, colors, and quantity to help process your order faster and more reliable.</p>
                        <h2 className="" style={{ color: "#1b80ad" }}>Have More Queries?</h2>
                        <p className="">To know more about our order process, 24/7 customer support is available to entertain your all queries & concerns.</p>
                        <p className="">To know more about our order process, 24/7 customer support is available to entertain your all queries  know more about our order process, 24/7 customer support is available to entertain your all queries  know more about our order process, 24/7 customer support is available to entertain your all queries & concerns.</p>
                    </div>

                    <div className="col-lg-5 ms-5">
                        <Quote />
                    </div>
                </div>


            </div>
        </div>
    );
}
export default ServiceSecond;