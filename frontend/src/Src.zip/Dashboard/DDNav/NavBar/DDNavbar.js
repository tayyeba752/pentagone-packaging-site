import React, { useState, useEffect } from "react";
import Button from '@mui/material/Button';
import "./NavBar.css";
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import logo2 from "../../../Assete/images/Logo/PentagonePng.png";

const DDNavbar = () => {
    const navigate = useNavigate();
    const [isSidebarOpen, setSidebarOpen] = useState(false);

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    let UserAvailable = localStorage.getItem("name");
    let UserRole = localStorage.getItem("role");

    useEffect(() => {
        if (!UserAvailable) {
            navigate({
                pathname: "/",
            });
        }
    }, [UserAvailable, navigate]);

    const Logout = () => {
        localStorage.clear();
    };

    let style1 = {
        fontWeight: "bolder",
        fontSize: "14px",
        color: "white"
    };

    return (
        <>

            <div className="sticky-top navbarDesign" style={{ marginTop: "-20px" }}>
                <nav className="navigation sw-megamenu" style={{ marginTop: "30px", border: "none" }} role="navigation">
                    <ul>
                        {/* <li className="ui-menu-item level0 fl-left"><a target="_blank" className="level-top cursorPointer"><b style={style1}><i className="fa fa-list mt-3" aria-hidden="true" style={{ fontSize: "30px" }}></i></b></a></li> */}
                        <li className="ui-menu-item level0 fl-left"><a target="_blank" className="level-top cursorPointer"><b style={style1}><Link to="/"><img src={logo2} style={{ height: "55px", width: "160px" }} alt="abc" /></Link></b></a></li>
                        <li className="ui-menu-item level0 fullwidth parent hoverFun"><Link to="/Admin/Dashboard" className="level-top cursorPointer" title="Home" ><b style={style1}>Home </b></Link></li>
                        <li className="ui-menu-item level0 fullwidth parent hoverFun"><Link to="/Admin/AddProduct" className="level-top cursorPointer" title="Add Product"><b style={style1}>Product</b></Link></li>
                        <li className="ui-menu-item level0 fullwidth parent hoverFun"><a className="level-top cursorPointer" title="Industries" ><b style={style1}>Products</b></a></li>
                        <li className="ui-menu-item level0 fullwidth parent hoverFun"><a className="level-top cursorPointer" title="Industries" ><b style={style1}>Services</b></a></li>
                        <li className="ui-menu-item level0 fl-right hoverFun" onClick={Logout}><span className="level-top cursorPointer"><b style={style1}>LogOut</b></span></li>
                    </ul>
                </nav>
            </div>
        </>
    );
};

export default DDNavbar;
