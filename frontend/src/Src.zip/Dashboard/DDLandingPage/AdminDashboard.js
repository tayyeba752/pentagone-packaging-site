import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import "./AdminDD.css";
import { Container, Row, Col, Card } from 'react-bootstrap';
import Env from "../../Environments/Env";
import axios from 'axios';
import Footer from '../../NavFoot/Footer/Footer';
import DDNavbar from '../DDNav/NavBar/DDNavbar';

const Box = ({ title, info, BlogNo }) => (
    <Col>
        <Card>
            <Card.Body style={{ height: "200px" }}>
                <Card.Title className="cardTitle"><center>{title}</center></Card.Title>
                <Card.Text style={{ color: "black" }} ><center><span style={{ fontWeight: "bold" }}>{info}</span>&nbsp;<span style={{ color: "#37b2fa", fontWeight: "bold" }}>{BlogNo}</span></center></Card.Text>
            </Card.Body>
        </Card>
    </Col>
);

const AdminDashboard = () => {
    const [BlogNum, setBlogNum] = useState(0)

    useEffect(() => {
        NoOfBlogs();
    }, [])


    const NoOfBlogs = () => {
        axios.get(`${Env.server}/api/blog/getAllBlogs`)
            .then((resp) => {
                let num = resp.data.blogs.length;
                setBlogNum(num)
            })
            .catch((err) => {
                console.log("err", err);
            })
    }


    return (
        <>
            <DDNavbar />
            <body style={{ fontFamily: "'Poppins', sans-serif" }} class="ori-digital-studio bg-white">
                <section id="ori-slider-1" style={{ marginTop: "140px", height: "500px" }} class="ori-slider-section-1 position-relative">
                    <Container >
                        <Row>
                            <Box title="Blogs" info="Total Blogs:" BlogNo={`${BlogNum}`} />
                            <Box title="Services" info="Total Services:" BlogNo="2" />
                            <Box title="Team" info="Total Team:" BlogNo="2" />
                            <Box title="Portfolio" info="Portfolio:" BlogNo="2" />
                            <Box title="Skills" info="Total Skills:" BlogNo="2" />
                        </Row>
                    </Container>
                </section>
            </body>
            <Footer />
        </>
    );
}

export default AdminDashboard;
